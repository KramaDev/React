export type ColorType={
    hex: string;
    name: string;
};