import { ColorType } from "../types/global";

export const data: ColorType[] = [
    { hex: "#4c1c24", name: "Bordo Red" },
    { hex: "#ffbe76", name: "Spiced Nectarine" },
    { hex: "#fba400", name: "Arancio Borealis" },
    { hex: "#18392b", name: "Dark Green Emerald" },
    { hex: "#836953", name: "Pastel Brown" }
];