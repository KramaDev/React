import Card from "./components/card";
import Grid from "./components/grid";
import Layout from "./components/layout";
import { data } from "./data/colors"; 
import { ColorType } from "./types/global"; 
const App = () => {
  return (
    <>
      <Layout>
        <h1 className="txt txt--lg">Favourite Colors</h1>
        <Grid>
          {data.map((color: ColorType, index: number) => ( 
            <Card key={index} data={color} /> 
          ))}
        </Grid>
        <h6 className="txt txt--sm">Created by Mario Kramarić as part of Typescript Homework</h6>
      </Layout>
    </>
  );
};

export default App;
