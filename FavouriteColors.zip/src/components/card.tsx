import { ColorType } from "../types/global";

type Props = {
    data: ColorType | ColorType[]; 
};

const Card = ({ data }: Props) => {
    
    const dataArray = Array.isArray(data) ? data : [data];

    return (
        <>
            {dataArray.map((color, index) => (
                <div className="card" key={index} style={{ backgroundColor: color.hex }}>
                    <div className="card__name">{color.name}</div>
                </div>
            ))}
        </>
    );
};

export default Card;
